const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const backToTop = document.getElementById("backToTop");
const year = document.getElementById("year");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

// Hero image slideshow
const slides = [...document.querySelectorAll(".hero-slide")];
const dotsContainer = document.getElementById("sliderDots");
let currentSlide = 0;

slides.forEach((_, index) => {
  const dot = document.createElement("button");
  dot.className = "slider-dot" + (index === 0 ? " active" : "");
  dot.setAttribute("aria-label", `Show slide ${index + 1}`);
  dot.addEventListener("click", () => showSlide(index));
  dotsContainer.appendChild(dot);
});

const dots = [...document.querySelectorAll(".slider-dot")];

function showSlide(index) {
  currentSlide = index;
  slides.forEach((slide, i) => slide.classList.toggle("active", i === index));
  dots.forEach((dot, i) => dot.classList.toggle("active", i === index));
}

setInterval(() => {
  showSlide((currentSlide + 1) % slides.length);
}, 5000);

// Back to top
window.addEventListener("scroll", () => {
  backToTop.classList.toggle("show", window.scrollY > 500);
});

backToTop.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

year.textContent = new Date().getFullYear();
